from django.db import models
from django.contrib.auth.models import User
class Personne(models.Model):
    nom = models.CharField(max_length=30)
    prenom = models.CharField(max_length=30)
    choix=[('M',"masculin"),('F','feminin'),('f','feminin'),('m',"masculin")]
    sexe = models.CharField(max_length=1,choices=choix)
    dateNaissance = models.DateField()
    matricule = models.CharField(max_length=10, blank=True)
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    # ,null=True,blank=True
    class Meta:
        abstract = True
    def __str__(self) -> str:
        return f"nom : {self.nom}  prenom: {self.prenom}  sexe : {self.sexe}"
    
    