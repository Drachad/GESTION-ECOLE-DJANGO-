from django.db import models
from .personne import Personne
class Enseignant(Personne):
    pass
    def __str__(self) -> str:
        return super().__str__()
    class Meta:
        verbose_name = "Enseignant"
        verbose_name_plural = "Enseignants"

    def save(self, *args, **kwargs):
            # Génération du matricule
            nom_part = self.nom[:2].upper()
            prenom_part = self.prenom[:2].upper()
            sexe_part = self.sexe.upper()
            annee_naissance = self.dateNaissance.year
            
            self.matricule = f"{nom_part}{prenom_part}{sexe_part}{annee_naissance}"

            # Appel du comportement de sauvegarde par défaut
            super().save(*args, **kwargs)