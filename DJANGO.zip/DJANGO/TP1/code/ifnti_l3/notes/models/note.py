from django.db import models
from .eleve import Eleve
from .matiere import Matiere
from django.core.validators import MinValueValidator, MaxValueValidator

class Note(models.Model):
    valeur = models.FloatField(null=True,
    validators=[MinValueValidator(0), MaxValueValidator(20)])
    eleve = models.ForeignKey(Eleve,on_delete=models.CASCADE)
    matiere = models.ForeignKey(Matiere,on_delete=models.CASCADE)
    def __str__(self) -> str:
        return str(self.valeur)
    class Meta:
        verbose_name = "Note"
        verbose_name_plural = "Notes"