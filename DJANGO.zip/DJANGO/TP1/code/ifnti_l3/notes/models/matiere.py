from django.db import models
from .enseignant import Enseignant
from .niveau import Niveau

class Matiere(models.Model):

    nom = models.CharField(max_length=50,unique=True)
    enseignant = models.ForeignKey(Enseignant,on_delete=models.SET_NULL,null=True)
    niveaux = models.ManyToManyField(Niveau)

    def __str__(self) -> str:
        return self.nom
    class Meta:
        verbose_name = "Matiere"
        verbose_name_plural = "Matieres"