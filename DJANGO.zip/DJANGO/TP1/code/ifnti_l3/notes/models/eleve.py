from django.db import models
from .personne import Personne
from .niveau import Niveau
from .matiere import Matiere

class Eleve (Personne):
    id_eleve = models.CharField(unique=True,max_length=50)
    niveau = models.ForeignKey(Niveau,on_delete=models.CASCADE)
    matiere = models.ManyToManyField(Matiere, blank=True, verbose_name="Matières que l'élève suit (peut être laissé vide)")
    
    def __str__(self) -> str:
        return super().__str__()
    class Meta:
        verbose_name = "Eleve"
        verbose_name_plural = "Eleves"
    

    def save(self, *args, **kwargs):
        # Génération du matricule
        nom_part = self.nom[:2].upper()
        prenom_part = self.prenom[:2].upper()
        sexe_part = self.sexe.upper()
        annee_naissance = self.dateNaissance.year
        
        self.matricule = f"{nom_part}{prenom_part}{sexe_part}{annee_naissance}"

        # Appel du comportement de sauvegarde par défaut
        super().save(*args, **kwargs)

        
        matieresEl=self.matiere.all()

        # print(len(matieresEl))

        if len(matieresEl)==0:

            print("toto")

            matieres_du_niveau = Matiere.objects.filter(niveaux=self.niveau)

            # print(matieres_du_niveau)

            self.matiere.set(matieres_du_niveau)

            super().save(*args, **kwargs)

            # print("Matières ajoutées :", self.matiere.all()) 

            # for mat in matieres_du_niveau :
            #     self.matiere.set(mat)
