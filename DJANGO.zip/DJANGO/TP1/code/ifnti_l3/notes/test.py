from notes.models import Niveau ;
niveau1 = Niveau(nom="L1");
niveau1.save();


niveau2 = Niveau(nom="L2");
niveau2.save();

niveau3 = Niveau(nom="L3");
niveau3.save();

from notes.models import Niveau ;
from notes.models import Eleve;
n1 = Niveau.objects.get(nom="L1");
e1 = Eleve(nom="Toune",prenom="Ouvo",sexe="M",dateNaissance="1995-10-25",id_eleve="90154846",niveau=n1);
e1.save();
n2 = Niveau.objects.get(nom="L2");
e2 = Eleve(nom="Falle",prenom="Eppa",sexe="F",dateNaissance="1993-5-2",id_eleve="90154234",niveau=n2);
e2.save();
n3 = Niveau.objects.get(nom="L3");
e3 = Eleve(nom="Jean",prenom="Aimar",sexe="M",dateNaissance="1993-12-6",id_eleve="90153546",niveau=n3);
e3.save();
n4 = Niveau.objects.get(nom="L3");
e4 = Eleve(nom="Djodi",prenom="rachad",sexe="M",dateNaissance="1884-12-6",id_eleve="90153238",niveau=n3);
e4.save();

from notes.models import Enseignant;
ens1 = Enseignant(nom="Claude",prenom="Stroffaibe",sexe="M",dateNaissance="1967-07-01");
ens1.save();
ens2 = Enseignant(nom="Abla",prenom="Sillon",sexe="F",dateNaissance="1960-08-02");
ens2.save();
ens3 = Enseignant(nom="Parlaf",prenom="Eunaitre",sexe="F",dateNaissance="1990-02-28");
ens3.save();













from notes.models import Matiere;
#matiere 1

 ens1 = Enseignant.objects.get(prenom="Stroffaibe");
 mat1 = Matiere(nom="Bases de la programmation",enseignant=ens1);
 mat1.save();
 mat1.niveaux.add(Niveau.objects.get(nom="L1"));

#matiere 2

 mat2 = Matiere(nom="Mathématiques");
 ens2 = Enseignant.objects.get(prenom="Sillon");
 mat2.enseignant = ens2;
 mat2.save();
  mat2.niveaux.add(Niveau.objects.get(nom="L1"),Niveau.objects.get(nom="L2"));

#matiere 3

mat3 = Matiere(nom="Langages Webs",enseignant=Enseignant.
objects.get(prenom="Sillon"));
 mat3.save();
  mat3.niveaux.add(Niveau.objects.get(nom="L2"),Niveau.objects.get(nom="L3"));

#matiere 4

mat4 = Matiere(nom="Gestion de projets",enseignant=Enseignant.
objects.get(prenom="Stroffaibe"));
mat4.save();
mat4.niveaux.add(Niveau.objects.get(nom="L3"));

#matiere 5

mat5 = Matiere(nom="Anglais",enseignant=Enseignant.objects.get(prenom="Eunaitre"));
mat5.save();
mat5.niveaux.add(Niveau.objects.get(nom="L2"),Niveau.objects.get(nom="L3"),Niveau.objects.get(nom="L1"));
