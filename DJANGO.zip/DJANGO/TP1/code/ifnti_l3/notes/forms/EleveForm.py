from django import forms
from notes.models import Eleve
from django.core.exceptions import ValidationError

class EleveForm(forms.ModelForm):
    class Meta:
        model = Eleve
        fields = ['id_eleve', 'nom', 'prenom', 'sexe','dateNaissance', 'niveau', 'user','matiere']  # Inclure tous les champs nécessaires
        labels = {
            'id_eleve': 'ID Élève',
            'nom': 'Nom',
            'prenom': 'Prénom',
            'dateNaissance':'dateNaissance',
            'sexe': 'Sexe',
            'niveau': 'Niveau',
            'matiere': 'Matière',
            'user' :'user'
        }
    def clean(self):
        cleaned_data = super().clean()
        niveau = cleaned_data.get('niveau')
        matieres = cleaned_data.get('matiere')
        matierNiveau = niveau.matiere_set.all() 

        # matiereNiveau=niveau.niveaux_set.all()

        prenom = self.cleaned_data.get('prenom')

        nom = self.cleaned_data.get('nom')
         #Vérification que les matières sont conformes au niveau
        for matiere in matieres:
            if matiere not in matierNiveau:
                    raise ValidationError(f"La matière {matiere} n'est pas conforme au niveau {niveau}.")
        if any(char.isdigit() for char in nom):
            raise ValidationError("Le nom ne doit pas contenir de chiffres.")
        
        if any(char.isdigit() for char in prenom):
            raise ValidationError("Le prénom ne doit pas contenir de chiffres.")
        return cleaned_data
        
        





           
        #     for matiere in matieres:

        #     if matiere not in matiereNiveau:

        #         raise forms.ValidationError(f"La matière {matiere} n'est pas conforme au niveau {niveau}.")
            
        # for i in nom:

        #     if i.isalpha()==False:

        #         raise forms.ValidationError("Le nom ne doit pas contenir de chiffres.")

        # return cleaned_data
