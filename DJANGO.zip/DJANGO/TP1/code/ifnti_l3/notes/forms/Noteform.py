from django.forms import ModelForm
from ..models import Note
from django.core.validators import MinValueValidator,MaxValueValidator
class NoteForm(ModelForm):
    class Meta:
        model = Note
        fields = ["valeur"]
        labels = {"valeur": "Note sur 20"}
        validators = [
                MinValueValidator(0,message="La note doit etre supérieure ou égale à 0."),
                MaxValueValidator(20,message="La note doit etre inférieure ou égale à 20.")
                ]
        