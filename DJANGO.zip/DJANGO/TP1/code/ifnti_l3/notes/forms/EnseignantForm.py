from django import forms
from ..models import Enseignant

class EnseignantForm(forms.ModelForm):
    class Meta:
        model = Enseignant
        fields = ['nom', 'prenom', 'sexe','dateNaissance']  # Inclure les champs nécessaires
        labels = {
            'nom': 'Nom',
            'prenom': 'Prénom',
            'dateNaissance':'dateNaissance',
            'sexe': 'Sexe',
        }
    def clean_nom(self):
        nom = self.cleaned_data.get('nom')
        if any(char.isdigit() for char in nom):
            raise forms.ValidationError("Le nom ne doit pas contenir de chiffres.")
        return nom

    def clean_prenom(self):
        prenom = self.cleaned_data.get('prenom')
        if any(char.isdigit() for char in prenom):
            raise forms.ValidationError("Le prénom ne doit pas contenir de chiffres.")
        return prenom
