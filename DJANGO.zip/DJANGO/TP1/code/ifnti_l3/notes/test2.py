<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        form {
            background: white;
            padding: 10px; /* Reduced padding */
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            max-width: 300px; /* Reduced max-width */
            margin: auto;
        }

        label {
            display: block;
            margin-bottom: 3px; /* Reduced margin */
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"] {
            width: 90%;
            padding: 5px; /* Reduced padding */
            margin-bottom: 10px; /* Reduced margin */
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            background-color: #28a745;
            color: white;
            padding: 5px 10px; /* Reduced padding */
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%; /* Full width button */
        }

        button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <form action="{% url 'notes:add_note' matiere_id eleve_id %}" method="post">
        {% csrf_token %}
        <label for="eleve">Nom Eleve</label>
        <input type="text" name="eleve" id="eleve" value="{{ eleve.nom}}">
        <label for="matiere">Matiere</label>
        <input type="text" name="matiere" id="matiere" value="{{matiere.nom}}">
        <label for="note">Note</label>
        <input type="number" id="note" name="note">
        <button type="submit">Submit</button>
    </form>
</body>
</html> -->