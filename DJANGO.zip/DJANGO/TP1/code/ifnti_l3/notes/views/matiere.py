
from django.shortcuts import render,get_object_or_404
from django.http import HttpResponse
from ..models import Matiere, Eleve

from django.contrib.auth.decorators import login_required, permission_required

@login_required(login_url="/accounts/login/")
def matieres(request):
    matieres = Matiere.objects.all()
    return render(request, "notes/matieres.html",{'matieres':matieres})

@login_required(login_url="/accounts/login/")  
def matiere(request,id):
    matiere = get_object_or_404(Matiere,pk=id)
   
    return render(request,'notes/matiere.html',{'matiere':matiere})