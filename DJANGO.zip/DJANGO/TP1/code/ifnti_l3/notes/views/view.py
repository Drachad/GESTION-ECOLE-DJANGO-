from django.shortcuts import render, redirect
from ..forms.EleveForm import EleveForm
from ..forms.EnseignantForm import EnseignantForm
from ..models import Eleve, Enseignant

from django.contrib.auth.decorators import login_required, permission_required

# Vue pour ajouter un élève
@login_required(login_url="/accounts/login/")
@permission_required('notes.add_eleve')
def add_eleve(request):
    if request.method == "POST":
        form = EleveForm(request.POST)
        if form.is_valid():
            # form.save()

            nomE=form.cleaned_data.get("nom")
            prenomE=form.cleaned_data.get("prenom")
            dateE=form.cleaned_data.get("dateNaissance")
            niveauE=form.cleaned_data.get("niveau")
            idE=form.cleaned_data.get("id_eleve")
            sexeE=form.cleaned_data.get("sexe")

            eleve=Eleve(id_eleve=idE, nom=nomE, prenom=prenomE, niveau=niveauE, sexe=sexeE, dateNaissance=dateE)

            eleve.save()

            

            return redirect('/notes/eleves')  # Rediriger vers la page des élèves après l'enregistrement
    else:
        form = EleveForm()
    return render(request, 'notes/add_eleve.html', {'form': form})


# Vue pour ajouter un enseignant
@login_required(login_url="/accounts/login/")
@permission_required('notes.add_enseignant')
def add_enseignant(request):
    if request.method == "POST":
        form = EnseignantForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/notes/enseignants')  # Rediriger vers la page des enseignants après l'enregistrement
    else:
        form = EnseignantForm()
    return render(request, 'notes/add_enseignant.html', {'form': form})

# Vue pour mettre à jour un élève
@login_required(login_url="/accounts/login/")
@permission_required('notes.add_eleve')
def update_eleve(request, eleve_id):
    eleve = Eleve.objects.get(pk=eleve_id)
    if request.method == "POST":
        form = EleveForm(request.POST, instance=eleve)
        if form.is_valid():
            form.save()
            return redirect('/notes/eleves')  # Rediriger après la mise à jour
    else:
        form = EleveForm(instance=eleve)
    return render(request, 'notes/update_eleve.html', {'form': form})

# Vue pour mettre à jour un enseignant
@login_required(login_url="/accounts/login/")
@permission_required('notes.add_enseignant')
def update_enseignant(request, enseignant_id):
    enseignant = Enseignant.objects.get(pk=enseignant_id)
    if request.method == "POST":
        form = EnseignantForm(request.POST, instance=enseignant)
        if form.is_valid():
            form.save()
            return redirect('/notes/enseignants')  # Rediriger après la mise à jour
    else:
        form = EnseignantForm(instance=enseignant)
    return render(request, 'notes/update_enseignant.html', {'form': form})
