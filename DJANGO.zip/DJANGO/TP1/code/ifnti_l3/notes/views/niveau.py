from django.shortcuts import render,get_object_or_404
from django.http import HttpResponse

from ..models import Niveau
from ..models import Matiere
from django.contrib.auth.decorators import login_required, permission_required

@login_required(login_url="/accounts/login/")
def niveau(request,id):
    niveau = get_object_or_404(Niveau,pk=id)
    matiere = Matiere.objects.filter(niveaux=niveau)
    return render(request,'notes/niveau.html',{'niveau':niveau,'matieres':matiere})
    
