# views.py
from django.shortcuts import render
from ..models import Eleve

def home(request):
    eleves = Eleve.objects.all()
    return render(request, 'home.html',{'eleves':eleves})
