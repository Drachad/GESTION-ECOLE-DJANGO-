from django.shortcuts import render
from django.http import HttpResponse

from ..models import Eleve,Niveau,Note,Matiere,Enseignant

def index(request):
    list_eleve = Eleve.objects.all()
    list_matiere= Matiere.objects.all()
    return render(request, "notes/index.html",{'eleve':list_eleve,'matieres':list_matiere})

