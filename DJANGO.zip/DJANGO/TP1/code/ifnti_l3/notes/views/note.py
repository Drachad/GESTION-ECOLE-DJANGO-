from django.http import HttpResponse
from django.shortcuts import render,redirect
from ..models import Eleve
from ..models import Matiere
from ..models import Note
from ..forms.Noteform import NoteForm
from django.forms import modelformset_factory
from django.contrib.auth.decorators import login_required, permission_required


# def add_note(request, matiere_id, eleve_id):
#     matiere = Matiere.objects.get(pk=matiere_id)
#     eleve = Eleve.objects.get(pk=eleve_id)
#     if request.method == "POST":
#         valeur = request.POST.get("note")
#         note = Note(eleve_id=eleve_id, matiere_id=matiere_id,valeur=valeur)
#         note.save()
#         return redirect("/notes/eleves")
#     else:
#         if (eleve.matiere.filter(pk=matiere_id)):
#             return render(request, "notes/add_note.html", locals())
#         else:
            
#             return HttpResponse("erreur eleve")
@login_required(login_url="/accounts/login/")
@permission_required('notes.add_note')
def add_note(request, matiere_id, eleve_id):
    matiere = Matiere.objects.get(pk=matiere_id)
    eleve = Eleve.objects.get(pk=eleve_id)
    if request.method == "POST":
        form = NoteForm(request.POST)
        if form.is_valid():
            try:
                note = form.save(commit=False)
                note.eleve = eleve
                note.matiere = matiere
                note.save()
                return redirect('/notes/eleves')
            except:
                pass
    else:
        form = NoteForm()
    return render(request, 'notes/add_note.html',{"form":form})

@login_required(login_url="/accounts/login/")
@permission_required('notes.add_notes')
def add_notes(request, matiere_id):
    matiere = Matiere.objects.get(pk=matiere_id)
    eleves = Eleve.objects.filter(matiere=matiere)  # Récupère tous les élèves pour cette matière
    
    # Crée un formulaire pour chaque élève
    NoteFormSet = []
    for eleve in eleves:
        form = NoteForm(request.POST or None, initial={'matiere': matiere, 'eleve': eleve})
        NoteFormSet.append((eleve, form))  # Associe chaque élève à son formulaire de note

    if request.method == "POST":
        is_valid = True
        for eleve, form in NoteFormSet:
            if form.is_valid():
                note = form.save(commit=False)
                note.eleve = eleve
                note.matiere = matiere
                note.save()
            else:
                is_valid = False
        if is_valid:
            return redirect('/notes/eleves')  # Redirige vers la page des élèves après enregistrement

    return render(request, 'notes/add_notes.html', {"NoteFormSet": NoteFormSet, "matiere": matiere})