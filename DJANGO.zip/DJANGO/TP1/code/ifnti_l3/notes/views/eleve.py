from django.shortcuts import render
from django.shortcuts import get_object_or_404
from django.http import HttpResponse

from ..models import Eleve
from ..models import Matiere
from django.contrib.auth.decorators import login_required, permission_required

@login_required(login_url="/accounts/login/")
def eleves(request):
    eleves = Eleve.objects.all()
    
    return render(request, "notes/eleves.html",{'eleves':eleves})

@login_required(login_url="/accounts/login/")
def eleve(request, id):
    eleve = get_object_or_404(Eleve,pk=id)
    matieres = eleve.matiere.all()
    print(matieres)
    return render(request,'notes/eleve.html',{'eleve':eleve,'matieres':matieres})