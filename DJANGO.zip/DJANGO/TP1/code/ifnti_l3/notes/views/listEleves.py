from django.http import FileResponse,Http404,HttpResponse

from ..models import Eleve,Niveau,Note

from Templating_ifnti.controleur import generate_pdf,generate_pdf2,generate_pdf3
from django.db.models import Avg

    
def listEleves(request):
    eleve = Eleve.objects.all()
    context = {}
    context["eleve"] = eleve
    print(context)
    generate_pdf(context)
    
    response = HttpResponse(
    open('Templating_ifnti/out/liste_eleves.pdf', 'rb').read(),
    content_type='application/pdf')
    response['Content-Disposition'] = 'inline; filename="file.pdf"'
    
    return response


def liste_niveauElv(request,id):
    nivo = Niveau.objects.get(id=id)
    eleve = nivo.eleve_set.all()
    context = {}
    context["eleve"] = eleve
    print(context)
    generate_pdf(context)
    
    response = HttpResponse(
    open('Templating_ifnti/out/liste_eleves.pdf', 'rb').read(),
    content_type='application/pdf')
    response['Content-Disposition'] = 'inline; filename="file.pdf"'
    
    return response

def notesEleves(request, id):
    notes = Note.objects.filter(matiere=id)
    context = {'notes': notes}  
    generate_pdf2(context)  

    response = HttpResponse(
        open('Templating_ifnti/out/liste_note.pdf', 'rb').read(),
        content_type='application/pdf'
    )
    response['Content-Disposition'] = 'inline; filename="file.pdf"'
    return response

def notes_synthese(request):
    
    synthese = (
        Note.objects.values(
            'eleve__nom',        
            'eleve__prenom',     
            'matiere__nom'      
        )
        
        .annotate(moyenne=Avg('valeur'))  
        .order_by('eleve__nom', 'matiere__nom') 
    )

    context = {
        'synthese': synthese,
    }
    generate_pdf3(context)
    response = HttpResponse(
        open('Templating_ifnti/out/syntese_note.pdf', 'rb').read(),
        content_type='application/pdf'
    )
    response['Content-Disposition'] = 'inline; filename="file.pdf"'
    return response