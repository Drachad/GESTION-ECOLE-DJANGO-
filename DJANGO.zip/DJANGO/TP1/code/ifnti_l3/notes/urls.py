from django.urls import path
app_name = 'notes'
from . import views


urlpatterns = [
      
    # path('', views.index, name='index'), 
    path('', views.home, name='home'),
    path('eleves/', views.eleves, name='eleves'),   
    path('eleve/<id>', views.eleve, name='eleve'),
    path('matieres/', views.matieres, name='matieres'),   
    path('matiere/<id>', views.matiere, name='matiere'),
    path('niveau/<id>', views.niveau, name='niveau'),
    path('add_note/<int:matiere_id>/<int:eleve_id>',views.add_note, name = 'add_note'),
    path('add_notes/<int:matiere_id>/', views.add_notes, name='add_notes'), 

    path('add_eleve/', views.add_eleve, name='add_eleve'),
    path('listEleve/', views.listEleves, name='listEleves'),
    path('listMoyenne/', views.notes_synthese, name='listMoyenne'),
    path('listEleve/<id>', views.liste_niveauElv, name='listEleves'),
    path('listNote/<id>', views.notesEleves, name='listNote'),
    path('add_enseignant/', views.add_enseignant, name='add_enseignant'),
    path('update_eleve/<int:eleve_id>/', views.update_eleve, name='update_eleve'),
    path('update_enseignant/<int:enseignant_id>/', views.update_enseignant, name='update_enseignant'),  

]
