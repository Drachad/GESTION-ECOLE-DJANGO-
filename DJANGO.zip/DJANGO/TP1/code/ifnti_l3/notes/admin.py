from django.contrib import admin

from notes.models import Niveau,Eleve,Enseignant,Matiere
from .forms.EleveForm import EleveForm
class EleveAdmin(admin.ModelAdmin):
    form = EleveForm
    list_display = ('nom', 'prenom', 'niveau', 'dateNaissance')
    list_filter = ('niveau', 'matiere')
    search_fields = ('nom', 'prenom')
    readonly_fields = ('id_eleve',)
    list_editable = ('niveau',)
    date_hierarchy = 'dateNaissance'
    save_on_top = True
    filter_horizontal = ('matiere',)
    empty_value_display = '- vide -'
    save_as = True
    save_as_continue = True
    list_per_page = 10
admin.site.site_header= 'IFNTI APPLICATION GESTION NOTE'
admin.site.register(Niveau)
admin.site.register(Eleve, EleveAdmin)
admin.site.register(Enseignant)
admin.site.register(Matiere)





